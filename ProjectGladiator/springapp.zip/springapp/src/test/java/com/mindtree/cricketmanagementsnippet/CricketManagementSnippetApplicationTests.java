package com.mindtree.cricketmanagementsnippet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CricketManagementSnippetApplicationTests {

	@Test
	void contextLoads() {
	}

}
