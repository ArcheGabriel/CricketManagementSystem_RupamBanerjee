package com.mindtree.cricketmanagementsnippet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CricketManagementSnippetApplication {

	public static void main(String[] args) {
		SpringApplication.run(CricketManagementSnippetApplication.class, args);
	}

}
