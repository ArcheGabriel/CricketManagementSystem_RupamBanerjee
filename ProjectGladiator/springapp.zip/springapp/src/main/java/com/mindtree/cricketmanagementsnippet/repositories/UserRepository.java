package com.mindtree.cricketmanagementsnippet.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.cricketmanagementsnippet.models.User;

@Repository
public interface UserRepository extends JpaRepository<User,Integer> {

	User findByEmailAndUsername(String email, String username);


}
